package http://hl7.org/fhir/us/carin-bb/ImplementationGuide/CARIN-RTPBC;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class CarinRtpbcRequestCoverageIdentifiers {

}
